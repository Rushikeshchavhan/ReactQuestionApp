import React from 'react'
import App from "./App";
import Progress from 'react-progressbar';


export default function AppContainer(props) {

    const handleUploadImage=(e)=>{
       alert("successfully submitted")
    }

    return (
        <form onSubmit={e => handleUploadImage(e)}>
        <div>
            <progress id="file" typeof="progress" value={props.val} max="100">{props.val}</progress>
            <br></br>
            <label for="file"><h5>Assessment Progress </h5></label>
            

            <App val="16" que="Are you a good listener?" />
            <App val="33" que="How often do you manage to meet your deadlines at work?" />
            <App val="49" que="I understand why people are being difficult to me?" />
            <App val="67" que="How often do you manage to meet your deadlines at work?" />
            <App val="84" que="I understand why people are being difficult to me??" />
            <App val="55" que="How often do you manage to meet your deadlines at work??" />

            <button onclick="myFunction()">Finish</button>
            <br></br>
            <br></br>
        </div>
        </form>
    )
}
