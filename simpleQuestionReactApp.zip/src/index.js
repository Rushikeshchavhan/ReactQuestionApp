// who render the App component => index.js
import React from "react";
import ReactDOM from "react-dom";
import AppContainer from "./AppContainer";



ReactDOM.render(<AppContainer />, document.getElementById("root"));
