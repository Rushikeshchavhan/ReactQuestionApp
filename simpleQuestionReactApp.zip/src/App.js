import React, { Component } from 'react'
import "./App.css";
import { Slider } from "@material-ui/core";



export default function App(props) {


        return (

                <React.Fragment>
                        <div id="edge">
                                <center>

                                       

                                        <div id="query">
                                                <h4>{props.que}</h4>
                                        </div><br></br>

                                        <div className="slider">
                                                <p>never always</p>
                                                <Slider />
                                                <h6>1 2 3 4 5 6 7 8 9 10</h6>
                                                <br></br>
                                        </div>

                                </center>
                        </div>
                </React.Fragment>

        )
}


